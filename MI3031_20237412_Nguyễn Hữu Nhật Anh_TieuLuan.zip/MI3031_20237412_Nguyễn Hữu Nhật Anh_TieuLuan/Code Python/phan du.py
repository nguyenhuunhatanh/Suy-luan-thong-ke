import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

# =========================
# 1) Đọc dữ liệu
# =========================
df = pd.read_csv("data ck sltk.csv")
df.columns = df.columns.str.strip()

# =========================
# 2) Tạo Y và X (ĐÚNG MÔ HÌNH BÁO CÁO)
# =========================
Y = df["energy (kWh/100km)"].to_numpy(dtype=float).reshape(-1, 1)

X_raw = df[[
    "top speed",
    "horsepower",
    "battery capacity (kWh)",
    "range"
]].to_numpy(dtype=float)

# Thêm cột hệ số chặn
X = np.hstack([np.ones((X_raw.shape[0], 1)), X_raw])

n = X.shape[0]
p = X.shape[1]          # số tham số (k + 1)
df_resid = n - p        # bậc tự do phần dư

# =========================
# 3) Ước lượng OLS
# =========================
beta_hat = np.linalg.inv(X.T @ X) @ (X.T @ Y)
Y_hat = X @ beta_hat

# =========================
# 4) KIỂM TRA PHẦN DƯ (THEO SLIDE CÔ THỦY)
# =========================

# (1) Phần dư
e_hat = Y - Y_hat

# (2) Tổng bình phương sai số
SSE = float(e_hat.T @ e_hat)

# (3) Ước lượng phương sai sai số
sigma2_hat = SSE / df_resid
sigma_hat = np.sqrt(sigma2_hat)

# (4) Phần dư chuẩn hoá
r = (e_hat / sigma_hat).flatten()

# =========================
# 5) In kết quả để ghi báo cáo
# =========================
print("=== KIỂM TRA PHẦN DƯ (Residual diagnostics) ===")
print(f"n = {n} | p = {p} | n - p = {df_resid}")
print(f"SSE = {SSE:.6f}")
print(f"sigma^2_hat = {sigma2_hat:.6f}")
print(f"sigma_hat = {sigma_hat:.6f}")

# =========================
# 6) Q–Q plot phần dư chuẩn hoá
# =========================
plt.figure(figsize=(6,6))
stats.probplot(r, dist="norm", plot=plt)
plt.title("Q–Q plot của phần dư chuẩn hoá", fontsize=12)
plt.xlabel("Phân vị lý thuyết")
plt.ylabel("Phân vị quan sát")
plt.grid(alpha=0.3)
plt.tight_layout()
plt.show()
