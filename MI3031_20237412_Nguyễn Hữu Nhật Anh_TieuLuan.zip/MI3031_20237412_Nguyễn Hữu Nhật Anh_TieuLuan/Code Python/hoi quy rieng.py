import numpy as np
import pandas as pd

print("=== START ===")

# ===== 1) Đọc dữ liệu =====
df = pd.read_csv("data ck sltk.csv")
df.columns = df.columns.str.strip()

# ===== 2) Lập Y, X theo mô hình báo cáo: Y ~ S + P + B + R =====
Y = df["energy (kWh/100km)"].to_numpy(dtype=float).reshape(-1, 1)

X_raw = df[["top speed", "horsepower",
            "battery capacity (kWh)", "range"]].to_numpy(dtype=float)

# Thêm cột hệ số chặn (beta0)
X = np.hstack([np.ones((X_raw.shape[0], 1)), X_raw])

n = X.shape[0]
p = X.shape[1]      # số tham số (gồm beta0)
k = p - 1           # số biến giải thích
dfree = n - p       # bậc tự do phần dư

# ===== 3) OLS: beta_hat =====
XtX = X.T @ X
C = np.linalg.inv(XtX)                 # C = (X'X)^(-1)
beta_hat = C @ (X.T @ Y)

# ===== 4) SSE, sigma^2_hat =====
Y_hat = X @ beta_hat
e_hat = Y - Y_hat
SSE = float(e_hat.T @ e_hat)           # SSE = e'e
sigma2_hat = SSE / dfree               # sigma^2_hat = SSE/(n-p)

# ===== 5) se(beta_hat_j) và t0 theo slide =====
# se(beta_j) = sqrt(sigma^2_hat * C_jj)
se_beta = np.sqrt(np.diag(C) * sigma2_hat).reshape(-1, 1)

# Kiểm định H0: beta_j = 0  (beta_j0 = 0)
beta0_vec = np.zeros_like(beta_hat)
t0 = (beta_hat - beta0_vec) / se_beta

# ===== 6) In bảng kết quả =====
names = ["β0", "β1_top_speed", "β2_horsepower", "β3_battery", "β4_range"]

out = pd.DataFrame(
    np.hstack([beta_hat, se_beta, t0]),
    index=names,
    columns=[r" β̂_j", r"se(β̂_j)", r"t₀"]
)

print("\n=== KIỂM ĐỊNH GIẢ THUYẾT VỀ HỆ SỐ HỒI QUY RIÊNG (t-test) ===")
print(f"n = {n} | k = {k} | p = {p} | df = n - p = {dfree}")
print(f"SSE = {SSE:.10f}")
print(f"sigma^2_hat = SSE/(n-p) = {sigma2_hat:.10f}\n")

# in đẹp (giữ đủ số để bạn copy kết quả)
pd.set_option("display.float_format", "{:,.6f}".format)
print(out.to_string())

print("=== END ===")

