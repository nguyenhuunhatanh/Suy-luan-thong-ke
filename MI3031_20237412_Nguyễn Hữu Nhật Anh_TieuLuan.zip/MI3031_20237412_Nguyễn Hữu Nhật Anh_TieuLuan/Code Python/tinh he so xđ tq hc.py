import numpy as np
import pandas as pd

print("=== START ===")

# =========================
# 1) Đọc dữ liệu
# =========================
df = pd.read_csv("data ck sltk.csv")
df.columns = df.columns.str.strip()

# =========================
# 2) Tạo y và X theo mô hình báo cáo (S, P, B, R)
# =========================
y = df["energy (kWh/100km)"].to_numpy(dtype=float).reshape(-1, 1)

X_raw = df[["top speed", "horsepower",
            "battery capacity (kWh)", "range"]].to_numpy(dtype=float)

# Thêm cột hệ số chặn
X = np.hstack([np.ones((X_raw.shape[0], 1)), X_raw])

# =========================
# 3) OLS: beta_hat
# =========================
beta_hat = np.linalg.inv(X.T @ X) @ (X.T @ y)

# =========================
# 4) Kích thước (đúng theo slide)
# =========================
n = y.shape[0]
p = X.shape[1]      # số tham số (bao gồm beta0)
k = p - 1           # số biến giải thích (không tính hệ số chặn)

# =========================
# 5) SST, SSR, SSE (THEO CÔNG THỨC MA TRẬN TRONG SLIDE)
# =========================
sum_y = float(np.sum(y))
yTy = float(y.T @ y)
betaXtY = float(beta_hat.T @ X.T @ y)

SST = yTy - (sum_y**2) / n
SSR = betaXtY - (sum_y**2) / n
SSE = yTy - betaXtY

# =========================
# 6) R^2, R, R^2_adj (đúng ký hiệu trong slide)
# =========================
R2 = SSR / SST
R = np.sqrt(R2)

R2_adj = 1 - (SSE/(n - p)) / (SST/(n - 1))

# =========================
# 7) In kết quả (đúng style để đưa vào báo cáo)
# =========================
print("\n=== HỆ SỐ ĐÁNH GIÁ MÔ HÌNH ===")
print(f"n = {n} | k = {k} | p = {p} | (n - p) = {n - p}")
print(f"SST = {SST:.10f}")
print(f"SSR = {SSR:.10f}")
print(f"SSE = {SSE:.10f}")
print(f"R^2 = SSR/SST = {R2:.6f}")
print(f"R   = sqrt(R^2) = {R:.6f}")
print(f"R^2_adj = 1 - (SSE/(n-p)) / (SST/(n-1)) = {R2_adj:.6f}")

# (tuỳ chọn) kiểm tra SST = SSR + SSE
print(f"Check: SST - (SSR + SSE) = {SST - (SSR + SSE):.10e}")

print("=== END ===")
