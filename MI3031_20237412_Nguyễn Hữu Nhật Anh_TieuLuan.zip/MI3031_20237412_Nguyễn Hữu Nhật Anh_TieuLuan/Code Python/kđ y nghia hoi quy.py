import numpy as np
import pandas as pd

# =========================
# Đọc dữ liệu
# =========================
df = pd.read_csv("data ck sltk.csv")
df.columns = df.columns.str.strip()

# y
y = df["energy (kWh/100km)"].to_numpy(dtype=float).reshape(-1, 1)

# X (S, P, B, R)
X_raw = df[["top speed", "horsepower",
            "battery capacity (kWh)", "range"]].to_numpy(dtype=float)
X = np.hstack([np.ones((X_raw.shape[0], 1)), X_raw])

# =========================
# OLS (đã dùng ở phần trước, giữ lại để tính SSR)
# =========================
beta_hat = np.linalg.inv(X.T @ X) @ (X.T @ y)

# =========================
# Kích thước
# =========================
n = y.shape[0]
p = X.shape[1]
k = p - 1
v1 = k
v2 = n - p

# =========================
# SST, SSR, SSE (đúng công thức slide)
# =========================
sum_y = float(np.sum(y))
yTy = float(y.T @ y)
betaXtY = float(beta_hat.T @ X.T @ y)

SST = yTy - (sum_y**2) / n
SSR = betaXtY - (sum_y**2) / n
SSE = yTy - betaXtY

# =========================
# F-test
# =========================
MSR = SSR / k
MSE = SSE / (n - p)
F0 = MSR / MSE

# =========================
# IN KẾT QUẢ (ĐÚNG NHƯ BẠN CẦN)
# =========================
print("=== KIỂM ĐỊNH Ý NGHĨA CỦA HỒI QUY (F-test) ===")
print(f"n = {n} | k = {k} | p = {p}")
print(f"v1 = k = {v1}")
print(f"v2 = n - p = {v2}")
print(f"SST = {SST}")
print(f"SSR = {SSR}")
print(f"SSE = {SSE}")
print(f"MSR = {MSR}")
print(f"MSE = {MSE}")
print(f"F0  = {F0}")
print(f"Check: SST - (SSR + SSE) = {SST - (SSR + SSE):.10e}")
