import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

# =========================
# 0) Thiết lập chung
# =========================
os.makedirs("figures", exist_ok=True)

# Font tiếng Việt (nếu máy bạn có Arial/Times New Roman thì đổi sang cho đẹp)
plt.rcParams["font.family"] = "DejaVu Sans"
plt.rcParams["axes.unicode_minus"] = False

# =========================
# 1) Đọc dữ liệu
# =========================
df = pd.read_csv("data ck sltk.csv")
df.columns = df.columns.str.strip()

y_col = "energy (kWh/100km)"
x_cols = ["top speed", "horsepower", "battery capacity (kWh)", "range"]

# Ép kiểu số, bỏ dòng thiếu
df = df[[y_col] + x_cols].apply(pd.to_numeric, errors="coerce").dropna()

Y = df[y_col].to_numpy(dtype=float).reshape(-1, 1)
X_raw = df[x_cols].to_numpy(dtype=float)
X = np.hstack([np.ones((X_raw.shape[0], 1)), X_raw])

n = X.shape[0]
p = X.shape[1]
df_resid = n - p

# =========================
# 2) OLS + phần dư (phục vụ đồ thị)
# =========================
beta_hat = np.linalg.inv(X.T @ X) @ (X.T @ Y)
Y_hat = X @ beta_hat
e_hat = (Y - Y_hat)

SSE = float((e_hat.T @ e_hat).item())        # SSE = ê'ê (tránh warning NumPy)
sigma2_hat = SSE / df_resid
sigma_hat = float(np.sqrt(sigma2_hat))
r = (e_hat / sigma_hat).flatten()            # phần dư chuẩn hoá r_i

# =========================
# HÀM LƯU FIG
# =========================
def savefig(name):
    path = os.path.join("figures", name)
    plt.tight_layout()
    plt.savefig(path, dpi=300)
    print("Đã lưu:", path)

# =========================
# NHÃN TIẾNG VIỆT
# =========================
vn_labels = {
    "top speed": "Tốc độ tối đa (km/h)",
    "horsepower": "Công suất (mã lực)",
    "battery capacity (kWh)": "Dung lượng pin (kWh)",
    "range": "Tầm hoạt động (km)",
    y_col: "Mức tiêu thụ năng lượng (kWh/100km)"
}

# ==========================================================
# BIỂU ĐỒ 1: Histogram Y (mức tiêu thụ năng lượng)
# ==========================================================
plt.figure(figsize=(6.5, 4.5))
plt.hist(df[y_col], bins=20, edgecolor="black")
plt.title("Phân phối mức tiêu thụ năng lượng", fontsize=12)
plt.xlabel(vn_labels[y_col])
plt.ylabel("Tần suất")
savefig("01_hist_energy.png")
plt.show()

# ==========================================================
# BIỂU ĐỒ 2: Boxplot các biến chính (energy + 4 biến X)
# ==========================================================
plt.figure(figsize=(9, 4.5))
data_box = [df[y_col].values] + [df[c].values for c in x_cols]
labels_box = ["energy", "top speed", "horsepower", "battery", "range"]
plt.boxplot(data_box, labels=labels_box, showfliers=True)
plt.title("Biểu đồ hộp (Boxplot) các biến chính", fontsize=12)
plt.xlabel("Biến")
plt.ylabel("Giá trị")
savefig("02_boxplot_variables.png")
plt.show()

# ==========================================================
# BIỂU ĐỒ 3-6: Scatter Y ~ từng X + đường xu hướng tuyến tính
# (chỉ dùng để minh hoạ trực quan)
# ==========================================================
for idx, col in enumerate(x_cols, start=3):
    x = df[col].to_numpy(dtype=float).flatten()
    y = df[y_col].to_numpy(dtype=float).flatten()

    # đường xu hướng tuyến tính y = a*x + b
    a, b = np.polyfit(x, y, 1)
    x_line = np.linspace(x.min(), x.max(), 200)
    y_line = a * x_line + b

    plt.figure(figsize=(6.5, 4.8))
    plt.scatter(x, y, s=18)
    plt.plot(x_line, y_line)
    plt.title(f"Mối quan hệ giữa {vn_labels[col]} và tiêu thụ năng lượng", fontsize=12)
    plt.xlabel(vn_labels[col])
    plt.ylabel(vn_labels[y_col])
    savefig(f"{idx:02d}_scatter_energy_vs_{col.replace(' ', '_').replace('(', '').replace(')', '')}.png")
    plt.show()

# ==========================================================
# BIỂU ĐỒ 7: Ma trận tương quan (heatmap)
# ==========================================================
corr = df[[y_col] + x_cols].corr()
labels_corr = ["energy", "top speed", "horsepower", "battery", "range"]

plt.figure(figsize=(7.2, 6))
im = plt.imshow(corr.values, aspect="auto")
plt.title("Ma trận tương quan giữa các biến", fontsize=12)
plt.xticks(range(len(labels_corr)), labels_corr, rotation=45, ha="right")
plt.yticks(range(len(labels_corr)), labels_corr)

# ghi hệ số tương quan lên từng ô
for i in range(corr.shape[0]):
    for j in range(corr.shape[1]):
        plt.text(j, i, f"{corr.values[i, j]:.2f}", ha="center", va="center")

plt.colorbar(im, fraction=0.046, pad=0.04)
savefig("07_corr_heatmap.png")
plt.show()

# ==========================================================
# BIỂU ĐỒ 8: Phần dư theo giá trị dự đoán (Residual vs Fitted)
# ==========================================================
plt.figure(figsize=(6.5, 4.8))
plt.scatter(Y_hat.flatten(), e_hat.flatten(), s=18)
plt.axhline(0)
plt.title("Phần dư theo giá trị dự đoán", fontsize=12)
plt.xlabel("Giá trị dự đoán Ŷ")
plt.ylabel("Phần dư ê")
savefig("08_residual_vs_fitted.png")
plt.show()

# ==========================================================
# BIỂU ĐỒ 9: Histogram phần dư chuẩn hoá r_i
# ==========================================================
plt.figure(figsize=(6.5, 4.5))
plt.hist(r, bins=20, edgecolor="black")
plt.title("Phân phối phần dư chuẩn hoá", fontsize=12)
plt.xlabel("rᵢ = êᵢ / σ̂")
plt.ylabel("Tần suất")
savefig("09_hist_standardized_residuals.png")
plt.show()

# ==========================================================
# BIỂU ĐỒ 10: Q–Q plot phần dư chuẩn hoá r_i
# ==========================================================
plt.figure(figsize=(6.2, 6.2))
stats.probplot(r, dist="norm", plot=plt)
plt.title("Biểu đồ Q–Q của phần dư chuẩn hoá rᵢ", fontsize=12)
plt.xlabel("Phân vị lý thuyết")
plt.ylabel("Phân vị quan sát")
savefig("10_qqplot_standardized_residuals.png")
plt.show()

# ==========================================================
# TÓM TẮT SỐ LIỆU PHẦN DƯ (để đưa vào báo cáo)
# ==========================================================
print("\n=== Tóm tắt số liệu phần dư (đưa vào báo cáo) ===")
print(f"n = {n} | p = {p} | n - p = {df_resid}")
print(f"SSE = {SSE:.6f}")
print(f"sigma^2_hat = {sigma2_hat:.6f}")
print(f"sigma_hat = {sigma_hat:.6f}")
