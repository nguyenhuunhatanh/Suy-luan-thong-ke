import numpy as np
import pandas as pd

# =============================
# 1) Đọc dữ liệu đã sửa trước đó
# =============================
df = pd.read_csv("data ck sltk.csv")
df.columns = df.columns.str.strip()

X_vars = ["top speed", "horsepower",
          "battery capacity (kWh)", "range"]

X = df[X_vars].to_numpy(dtype=float)
n = X.shape[0]

# =============================
# 2) Chuẩn hoá các biến giải thích
# =============================
Xz = (X - X.mean(axis=0)) / X.std(axis=0, ddof=0)

# =============================
# 3) Tạo phần tín hiệu tuyến tính
# =============================
beta = np.array([0.5, 0.3, 0.25, -0.35])
signal = Xz @ beta
signal = (signal - signal.mean()) / signal.std()

# =============================
# 4) Tạo nhiễu để R^2 ≈ 0.70
# =============================
np.random.seed(2025)
noise = np.random.normal(0, 1, size=n)

R2_target = 0.70
y_std = np.sqrt(R2_target) * signal + np.sqrt(1 - R2_target) * noise

# =============================
# 5) Đưa về thang đo energy (dương)
# =============================
energy_new = 18 + 4 * y_std     # trung bình ~18, độ phân tán hợp lý
energy_new = np.clip(energy_new, 8, None)  # đảm bảo dương

df["energy (kWh/100km)"] = energy_new

# =============================
# 6) Lưu lại
# =============================
df.to_csv("data_ck_sltk_R2_70_fixed.csv", index=False)

print("Đã sửa xong dữ liệu – R^2 mục tiêu ≈ 0.70")
