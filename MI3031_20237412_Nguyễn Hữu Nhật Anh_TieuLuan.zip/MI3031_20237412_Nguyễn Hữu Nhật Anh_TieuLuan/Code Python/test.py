# ============================================================
# MI3031 - CHỦ ĐỀ 2 (EV-only) | OLS summary format + VIF check
# Output: bảng "OLS Regression Results" giống hình bạn gửi
# ============================================================

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor

# -----------------------------
# 0) ĐỌC DỮ LIỆU
# -----------------------------
DATA_PATH = "data ck sltk.csv"  # <-- file của bạn

df = pd.read_csv(DATA_PATH)

# Fix lỗi tên cột có khoảng trắng thừa (vd: 'range ' / 'width ')
df.columns = df.columns.str.strip()

# -----------------------------
# 1) KHAI BÁO MÔ HÌNH (ĐÚNG BÁO CÁO)
# -----------------------------
y_col = "energy (kWh/100km)"
X_cols = ["top speed", "horsepower", "battery capacity (kWh)", "range"]

# check cột có tồn tại không
need_cols = [y_col] + X_cols
missing_cols = [c for c in need_cols if c not in df.columns]
if missing_cols:
    raise ValueError(
        f"Thiếu cột: {missing_cols}\n"
        f"Các cột hiện có:\n{list(df.columns)}"
    )

# lấy dữ liệu mô hình + làm sạch
model_df = df[need_cols].copy()

# ép kiểu số (tránh cột bị đọc thành text)
for c in need_cols:
    model_df[c] = pd.to_numeric(model_df[c], errors="coerce")

model_df = model_df.dropna().copy()

y = model_df[y_col]
X = model_df[X_cols]
X = sm.add_constant(X)  # thêm intercept (const)

# -----------------------------
# 2) CHẠY OLS & IN SUMMARY (FORMAT GIỐNG ẢNH)
# -----------------------------
model = sm.OLS(y, X).fit()

print("\n" + "="*90)
print("OLS Regression Results (MI3031 - Chủ đề 2 | EV-only)")
print("="*90)
print(model.summary())  # <- bảng format giống ảnh (có Cond. No.)

# -----------------------------
# 3) KIỂM TRA ĐA CỘNG TUYẾN: VIF
# -----------------------------
# VIF chỉ tính cho biến giải thích (có thể bỏ const khi diễn giải)
X_vif = sm.add_constant(model_df[X_cols])
vif_table = pd.DataFrame({
    "Variable": X_vif.columns,
    "VIF": [variance_inflation_factor(X_vif.values, i) for i in range(X_vif.shape[1])]
})

print("\n" + "="*90)
print("VIF (Variance Inflation Factor) - kiểm tra đa cộng tuyến")
print("="*90)
print(vif_table.to_string(index=False))

# -----------------------------
# 4) GỢI Ý NGƯỠNG KẾT LUẬN (IN RA CHO DỄ CHẤM)
# -----------------------------
cond_no = np.linalg.cond(X.values)
print("\n" + "="*90)
print("Gợi ý đọc kết quả đa cộng tuyến")
print("="*90)
print(f"Condition Number (tự tính): {cond_no:.3f}")
print("• Nếu VIF > 10: đa cộng tuyến mạnh (thường bị chấm là 'nghiêm trọng').")
print("• Nếu 5 < VIF <= 10: đa cộng tuyến vừa (cần nhận xét).")
print("• Nếu VIF <= 5: thường xem là ổn.")
print("• Cond. No. lớn (ví dụ > 30, > 100, > 1000) là dấu hiệu cần xem VIF + scale biến.")
