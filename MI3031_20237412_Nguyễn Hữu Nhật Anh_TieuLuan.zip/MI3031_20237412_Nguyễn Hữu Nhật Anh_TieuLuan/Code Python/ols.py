import pandas as pd
import numpy as np

print("=== START ===")

# 1) Đọc dữ liệu
df = pd.read_csv("data ck sltk.csv")
df.columns = df.columns.str.strip()
print("Rows, Cols:", df.shape)

# 2) Y
Y = df["energy (kWh/100km)"].to_numpy(dtype=float).reshape(-1, 1)

# 3) X (đúng mô hình mới: S, P, B, R)
X = df[["top speed", "horsepower", "battery capacity (kWh)", "range"]].to_numpy(dtype=float)

# 4) Thêm cột hệ số chặn
X = np.hstack([np.ones((X.shape[0], 1)), X])

# 5) OLS
beta_hat = np.linalg.inv(X.T @ X) @ (X.T @ Y)

beta_names = ["β0", "β1_top_speed", "β2_horsepower", "β3_battery", "β4_range"]
out = pd.DataFrame(beta_hat, index=beta_names, columns=["Estimate"])

print("\n=== BETA HAT (OLS) ===")
print(out.to_string())
print("\n=== END ===")
