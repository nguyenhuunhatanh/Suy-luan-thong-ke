import pandas as pd
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.tools.tools import add_constant
import seaborn as sns
import matplotlib.pyplot as plt

# 1. Đọc dữ liệu
df = pd.read_csv('data ck sltk.csv')

# 2. Chọn các biến độc lập theo mô hình trong báo cáo
features = ['battery capacity (kWh)', 'horsepower', 'range ', 'top speed']
# Lưu ý: Tên cột trong file CSV có thể có khoảng trắng thừa, cần xử lý (đã xử lý trong quá trình chạy)

# 3. Tính ma trận tương quan
corr_matrix = df[features].corr()
print("Ma trận tương quan:")
print(corr_matrix)

# 4. Tính hệ số VIF
# Thêm hằng số (intercept) để tính VIF chính xác
X = add_constant(df[features])
vif_data = pd.DataFrame()
vif_data["Biến"] = X.columns
vif_data["VIF"] = [variance_inflation_factor(X.values, i) for i in range(len(X.columns))]

print("\nKết quả VIF:")
print(vif_data)